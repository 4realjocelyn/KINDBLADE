
let playerName;

function startGame() {
    playerName = document.getElementById("username").value || "Akaza";

    const config = {
        type: Phaser.AUTO,
        width: 800,
        height: 600,
        backgroundColor: '#222',
        scene: {
            preload: preload,
            create: create,
            update: update
        }
    };

    new Phaser.Game(config);
}

function preload() {
    this.load.image('player', 'assets/images/player.png');
}

function create() {
    this.add.text(300, 50, `Welcome, ${playerName}`, { font: '20px Courier', fill: '#ffffff' });
    this.player = this.add.image(400, 300, 'player');
}

function update() {
    // Placeholder for game loop
}
